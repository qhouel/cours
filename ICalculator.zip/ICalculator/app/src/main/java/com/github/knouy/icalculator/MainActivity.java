package com.github.knouy.icalculator;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
  /**.*/
  private boolean addHasBeenClicked;
  /**.*/
  private boolean answerHasBeenClicked;
  /**.*/
  private boolean divideHasBeenClicked;
  /**.*/
  private boolean multiplyHasBeenClicked;
  /**.*/
  private boolean operatorHasBeenClicked;
  /**.*/
  private boolean subtractHasBeenClicked;
  /**.*/
  private Button allClear;
  /**.*/
  private double result0;
  /**.*/
  private double result1;
  /**.*/
  private TextView textView;

  /**.*/
  @Override
  protected void onCreate(final Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    this.allClear = findViewById(R.id.allClear);
    this.textView =  findViewById(R.id.textView);
  }

  /**.
   * @param v View */
  public void add(final View v) {
    this.allClear.setText("C");
    this.calculate();
    this.addHasBeenClicked = true;
    this.operatorHasBeenClicked = true;
    this.answerHasBeenClicked = false;
    this.divideHasBeenClicked = false;
    this.multiplyHasBeenClicked = false;
    this.subtractHasBeenClicked = false;
  }

  /**.
   * @param v View */
  public void allClear(final View v) {
    if (this.allClear.getText().toString().equals("AC")) {
      this.addHasBeenClicked = false;
      this.answerHasBeenClicked = false;
      this.divideHasBeenClicked = false;
      this.multiplyHasBeenClicked = false;
      this.operatorHasBeenClicked = false;
      this.subtractHasBeenClicked = false;
      this.result0 = 0.0;
      this.result1 = 0.0;
    }
    this.allClear.setText(getString(R.string.allClear));
    this.textView.setText("0");
  }

  /**.
   * @param v View */
  public void answer(final View v) {
    this.answerHasBeenClicked = true;
    boolean bln = !this.operatorHasBeenClicked || this.result1 != 0.0;
    if (this.addHasBeenClicked) {
      this.result1 = bln ? this.result1 + this.result0 : this.result0
        + this.result0;
    } else if (this.divideHasBeenClicked) {
      this.result1 = bln ? this.result1 / this.result0 : 1;
    } else if (this.multiplyHasBeenClicked) {
      this.result1 = bln ? this.result1 * this.result0 : this.result0
        * this.result0;
    } else if (this.subtractHasBeenClicked) {
      this.result1 = bln ? this.result1 - this.result0 : 0;
    }
    setText(this.result1);
  }

  /**.*/
  public void calculate() {
    if (!this.answerHasBeenClicked && this.result1 != 0.0) {
      if (this.addHasBeenClicked) {
        this.result1 += this.result0;
      } else if (this.divideHasBeenClicked) {
        this.result1 /= this.result0;
      } else if (this.multiplyHasBeenClicked) {
        this.result1 *= this.result0;
      } else if (this.subtractHasBeenClicked) {
        this.result1 -= this.result0;
      }
      setText(this.result1);
    }
    this.result0 =
    Double.parseDouble(this.textView.getText().toString().replace(",", "."));
  }

  /**.
   * @param v View */
  public void comma(final View v) {
    this.allClear.setText("C");
    if (!this.textView.getText().toString().contains(",")) {
      this.textView.setText(getString(R.string.comma0,
          this.textView.getText().toString()));
    }
  }

  /**.
   * @param v View */
  public void digit(final View v) {
    this.allClear.setText("C");
    Button btt = findViewById(v.getId());
    if (this.answerHasBeenClicked) {
      this.addHasBeenClicked = false;
      this.answerHasBeenClicked = false;
      this.divideHasBeenClicked = false;
      this.multiplyHasBeenClicked = false;
      this.operatorHasBeenClicked = false;
      this.subtractHasBeenClicked = false;
      this.result0 = 0.0;
      this.result1 = 0.0;
      this.textView.setText(btt.getText());
    } else if (!this.operatorHasBeenClicked) {
      if (this.textView.getText().toString().equals("0")) {
        this.textView.setText(btt.getText());
      } else {
        this.textView.setText(getString(R.string.digit,
            this.textView.getText().toString(), btt.getText()));
      }
    } else {
      this.operatorHasBeenClicked = false;
      this.textView.setText(btt.getText());
      if (this.result1 == 0.0) {
        this.result1 = this.result0;
      }
    }
    this.answerHasBeenClicked = false;
    this.result0 =
    Double.parseDouble(this.textView.getText().toString().replace(",", "."));
  }

  /**.
   * @param v View */
  public void divide(final View v) {
    this.calculate();
    this.divideHasBeenClicked = true;
    this.operatorHasBeenClicked = true;
    this.addHasBeenClicked = false;
    this.answerHasBeenClicked = false;
    this.multiplyHasBeenClicked = false;
    this.subtractHasBeenClicked = false;
  }

  /**.
   * @param v View */
  public void multiply(final View v) {
    this.calculate();
    this.multiplyHasBeenClicked = true;
    this.operatorHasBeenClicked = true;
    this.addHasBeenClicked = false;
    this.answerHasBeenClicked = false;
    this.divideHasBeenClicked = false;
    this.subtractHasBeenClicked = false;
  }

  /**.
   * @param v View */
  public void percent(final View v) {
    this.answerHasBeenClicked = true;
    this.operatorHasBeenClicked = true;
    final int prc = 100;
    this.result0 = this.result1 == 0.0 ? this.result0 / prc : this.result1
      * this.result0 / prc;
    setText(this.result0);
  }

  /**.
   * @param v View */
  public void plusMinus(final View v) {
    if (this.result0 != 0.0) {
      double dbl = Double.parseDouble(this.textView.getText().toString()
          .replace(",", "."));
      this.result0 = -dbl;
      setText(this.result0);
    }
  }

  /**.
   * @param dbl Double */
  public void setText(final Double dbl) {
    this.allClear.setText("C");
    String str = String.valueOf(dbl);
    this.textView.setText(str.endsWith(".0") ? str.substring(0, str.length()
        - 2) : str.replace(".", ","));
  }

  /**.
   * @param v View */
  public void subtract(final View v) {
    this.calculate();
    this.operatorHasBeenClicked = true;
    this.subtractHasBeenClicked = true;
    this.addHasBeenClicked = false;
    this.answerHasBeenClicked = false;
    this.divideHasBeenClicked = false;
    this.multiplyHasBeenClicked = false;
  }
}

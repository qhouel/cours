<form method= "post" action="">
	<table border =0>

	<tr> <td>Raison Sociale :</td>
		<td> <input type="text" name="RAISON_SOCIALE"></td></tr>
	
	<tr> <td>Siret :</td>
		<td> <input type="text" name="SIRET"></td></tr>

	<tr> <td>Nom :</td>
		<td> <input type="text" name="NOM"></td></tr>

	<tr> <td>Prénom :</td>
		<td> <input type="text" name="PRENOM"></td></tr>

	<tr> <td>Email :</td>
		<td> <input type="text" name="EMAIL"></td></tr>

	<tr> <td>Adresse :</td>
		<td> <input type="text" name="ADRESSE"></td></tr>

	<tr> <td>Ville :</td>
		<td> <input type="text" name="VILLE"></td></tr>

	<tr> <td>Code Postal :</td>
		<td> <input type="text" name="CODE_POSTAL"></td></tr>
	
	<tr> <td>Téléphone :</td>
		<td> <input type="text" name="TELEPHONE"></td></tr>

	<tr> <td>Mot de passe :</td>
		<td> <input type="text" name="MDP"></td></tr>

		<tr> <td> <input type="reset" name="Annuler" value="Annuler"></td>
			<td><input type="submit" name="Valider" value="Valider"></td></tr>
	</table>
</form>